import React from 'react';

const Cart = () => {
    return ( 
        <h1>Cart component</h1>
     );
}
 
export default Cart;
