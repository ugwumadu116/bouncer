import React from 'react';
import AppRoutes from './router'

import './App.css';

export default () => <AppRoutes />
